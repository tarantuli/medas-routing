<?php

declare(strict_types=1);

namespace Medas\Routing\Parameters;

readonly class Constant implements Parameter
{
    public function __construct(
        private string $name,
    )
    {
    }

    public function pattern(): string
    {
        return str_replace('/', '\\/', $this->name);
    }

    public function readablePattern(): string
    {
        return $this->name;
    }

    public function isValid(mixed $value): bool
    {
        return $value == $this->name;
    }

    public function name(): string|null
    {
        return null;
    }

    public function denormalize(string $value): string
    {
        return $value;
    }
}
